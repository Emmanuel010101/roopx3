version_flag = "v0.0.2-uncensored"

from scripts.roop_logging import logger

logger.info(f"roop {version_flag}")
